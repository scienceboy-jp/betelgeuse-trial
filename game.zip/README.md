# betelgeuse
ブログ内のノベルゲーム制作ブロジェクト

## Credit
### Music credit
- 曲名/作曲者/サイト名(URL)
- バッドブラック/かずち/Dova-syndrome(https://dova-s.jp/bgm/play4964.html)
- Koiwazurai/(不明)/Peritune(https://peritune.com/blog/2015/12/16/koiwazurai/)

### Sound credit
- OtoLogic
- VSQ
